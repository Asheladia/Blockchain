# DevChain

Chain ID 333

## Node 1

### Address

0x635eFEe576855b116A9aa2d3CeE8Afb1ef9947e4

### Start Command

geth --datadir node1 --mine --minerthreads 1

## Node 2

### Address

0xf50be6C477F9db716b3E11cc1cdDBc7462EDA46D

### Start Command

geth --datadir node2 --mine --port 30305 --bootnodes "enode://eb7d0389b9ed93256c0b1d27c6bc8ce06f5e4f381f6d9d4572484f770237ff4c8cfe877ba714c6fbd100f7a07f1ab37926ddbe0754f2deeab12eca4a68dc8902@127.0.0.1:30303" --ipcdisable
